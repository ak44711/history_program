#include<iostream>
#include<vector> 
using namespace std;
int count(vector<int>& a,int begin,int end){
    int sum = 0;
    for (int i = begin; i <=end;i++){
        sum += a[i];
    }
    return sum;
}
void find(vector<int>& a,int begin,int end){
    int mid = (begin + end) / 2;
    if(end-begin==1&&a[begin]>a[end]) {
        cout << "find fake money: " << end+1 << endl;
        return ;
    }
    if(end-begin==1&&a[begin]<a[end]) {
        cout << "find fake money: " << begin+1 << endl;
        return ;
    }
    if(begin-end==0) {
        cout << "find fake money��" << mid + 1 << endl;
        return ;
    }
    if((begin+end)%2==1) {
        if(count(a,begin,mid)<count(a,mid+1,end)){
             find(a, begin,  mid );
        }
        if(count(a,mid+1,end)<count(a,begin,mid)) {
             find(a, mid+1,  end);
        }
    }
    if((begin+end)%2==0&&count(a,begin,mid-1)==count(a,mid+1,end)) {
        cout << "find fake money: " << mid + 1 <<endl;
        return;
    }
    if((begin+end)%2==0) {
        if(count(a,begin,mid-1)<count(a,mid+1,end)) {
             find(a, begin, mid - 1);
        }
        if(count(a,begin,mid-1)>count(a,mid+1,end)) {
             find(a, mid + 1, end);
        }
    }
}
int main() {
    vector<int> a = {2,2,2,2,2,2,2,2,1};
    find(a, 0,a.size() - 1);
    vector<int> a1 = {2,2,2,2,1,2,2,2,2,2};
    find(a1, 0,a1.size() - 1);
    vector<int> a2 = {2,2,2,2,3,2,2,2,2};
    find(a2, 0,a2.size() - 1);
    vector<int> a3 = {1,2,2,2,2,2,2,2,2,2};
    find(a3, 0,a3.size() - 1);
    vector<int> a4 = {2,2,2,2,2,2,2,2,1};
    find(a4, 0,a4.size() - 1);
    vector<int> a5 = {2,2,1};
    find(a5, 0,a5.size() - 1);
    return 0;
}

